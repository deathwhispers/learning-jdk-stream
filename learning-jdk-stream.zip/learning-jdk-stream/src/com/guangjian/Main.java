package com.guangjian;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // write your code here


        ArrayList<String> list = new ArrayList<>();
        String str = new String();


    }
}
